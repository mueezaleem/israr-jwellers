const header = document.querySelector('.site-header');
const menuBtn = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');

function onScroll(){ header.classList.toggle('scrolled', window.scrollY > 30); }
onScroll(); window.addEventListener('scroll', onScroll, {passive:true});

menuBtn.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('.nav a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open'); menuBtn.setAttribute('aria-expanded','false');
}));

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => { if(entry.isIntersecting){ entry.target.classList.add('visible'); observer.unobserve(entry.target); } });
}, {threshold:.12});
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

document.querySelectorAll('.wa-service').forEach(card => {
  const service = card.dataset.service;
  const message = `Assalamualaikum, I'm interested in ${service}. Please share the price, available designs and timings. Thank you.`;
  card.href = `https://wa.me/923218382527?text=${encodeURIComponent(message)}`;
  card.target = '_blank'; card.rel = 'noopener';
});
